import { SEARCH_OUTPUT } from "./actionTypes";

export const searchOp = (payload) => ({
  type: SEARCH_OUTPUT,
  payload,
});
